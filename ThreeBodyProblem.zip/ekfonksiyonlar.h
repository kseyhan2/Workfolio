#ifndef EKFONKSIYONLAR_H
#define EKFONKSIYONLAR_H
#include "universe.cpp"
#include "canvas.cpp"






inline void y( ){ // Endline Fonksiyonu, kod yazımını kolaylaştırmak için kullanıldı
	
	std::cout<<std::endl;
	
}

inline void create(Universe *, canvas * );

#endif 
